package view;

import java.awt.*;
import java.awt.List;
import java.awt.event.*;
import java.io.*;
import java.sql.*;
import java.util.*;

import javax.swing.*;
import javax.swing.table.*;
import javax.xml.parsers.*;

import org.xml.sax.*;

import curr.*;
import model.*;

public class CountryList extends JFrame 
		implements ActionListener, MouseListener {
		
	Vector 					v; // data list
	Vector 					cols; //header
	
	DefaultTableModel		dtm; // includes ResultSet + header
	JTable 					jTable; //excel(ish) table
	JScrollPane				pane;
	JPanel					topPane;
	JButton					btnInsert, btnRefresh, btnToExcel, btnConverter, btnSearch;
	TextField				searchable;
	
	
	static CountryList		cList;
	static CountryProc		cProc;
	
	public CountryList() {
		super("Global Summit VIP List ver 1.0");
		
		initComponent();
		
		this.setLocation(500,300);
		this.setSize(800,600);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	private void initComponent() {
		
		dtm 		=	initTable();
		jTable		=	new JTable(dtm);
		
		pane		=	new JScrollPane(jTable);
		jTable.setAutoCreateRowSorter(true); //Automatic sort
		//add ScrollBar panel
		this.add(pane);
		
		//second panel
		topPane			=	new JPanel();
		btnInsert		=	new JButton("Add");
		topPane.add(btnInsert);
		btnRefresh		=	new JButton("Refresh");
		topPane.add(btnRefresh);
		btnConverter 	=	new JButton("Currency");
		topPane.add(btnConverter);
		searchable		=	new TextField(30);
		topPane.add(searchable);
		btnSearch		=	new JButton("Search");
		topPane.add(btnSearch);
		
		
		//btnToExcel = new JButton("To Excel");
		//topPane.add(btnToExcel);
		
		//place header at the top, but below the buttons
		this.add(topPane, BorderLayout.NORTH);
		
		this.btnInsert.addActionListener(this);
		this.btnRefresh.addActionListener(this);
		this.btnConverter.addActionListener(this);
		this.btnSearch.addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				String ss = searchable.getText();
				System.out.println(ss);
				
				Connection		  conn	=	null;
				PreparedStatement pstmt =	null;
				ResultSet			rs  =	null;
				String			   sql	=	"";
				conn	=	DBConn.getInstance();
				sql		= "SELECT NAME ,CAPITAL, CURRENCY, LANGUAGE, HEADOFGOVERN";
				sql		+= " FROM  COUNTRIES2";
				sql		+= " WHERE  NAME LIKE '%"+ss+"%' OR";
				sql		+= " CAPITAL LIKE '%"+ss+"%' OR";
				sql		+= " CURRENCY LIKE '%"+ss+"%' OR";
				sql		+= " LANGUAGE LIKE '%"+ss+"%' OR";
				sql		+= " HEADOFGOVERN LIKE '%"+ss+"%'";
				System.out.println(sql);
				try {
					pstmt	= conn.prepareStatement(sql);
					rs		= pstmt.executeQuery();
					v = new Vector(); //reset Vector
					while(rs.next()) {
						Vector member	=	new Vector();
						//another Vector in Vector
						member.add(rs.getString("name"));
						member.add(rs.getString("capital"));
						member.add(rs.getString("currency"));
						member.add(rs.getString("language"));
						member.add(rs.getString("headofgovern"));
						v.add(member);
						System.out.println("in:" + v);
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				} finally {
					try {
						if(rs!=null)	 rs.close();
						if(pstmt!=null)	 pstmt.close();
						// close conn only when program exit
						// otherwise, it closes whenever select,insert, etc
					} catch (SQLException e1) {
						e1.printStackTrace();
					}
				}
				
				cols 	= getColums();
				// guest data
				System.out.println(v);				
				DefaultTableModel dataModel = new DefaultTableModel(v, cols);
				
				jTable.setModel(dataModel);
				//fetching new JTable model
				jTable.repaint();
				//JButton btn = (JButton) e.getSource();
				//System.out.println(btn.getText());
				//new JTableSearch();
				
			}

			@Override
			public void mouseEntered(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseExited(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mousePressed(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void mouseReleased(MouseEvent arg0) {
				// TODO Auto-generated method stub
				
			}
			
		});
		
		//If you click any data (guests) in jTable
		this.jTable.addMouseListener(this);

	}
	private DefaultTableModel initTable() {
		// header
		cols 	= getColums();
		// guest data
		v		= getDataList();
		
		DefaultTableModel dtm = new DefaultTableModel(v, cols);
		return dtm;
		
	}

	private Vector getDataList() {
		CountriesDao		mDao	=	new CountriesDao();
		Vector			v		=	mDao.getMemberList();
		//another Vector in Vector
		return v;
	}
	

	private Vector getColums() {
		//header
		Vector cols = new Vector<>();
		cols.add("Country Name");
		cols.add("Capital");
		cols.add("Currency");
		cols.add("Language");
		cols.add("Head of govern");
		return cols;
	}
	
	public void jTableRefresh() {
		
		DefaultTableModel	dataModel = initTable();
		jTable.setModel(dataModel);
		//fetching new JTable model
		jTable.repaint();
		
	}
	
	public static void main(String[] args) {
		if(cList == null) {
			cList = new CountryList();
		}
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton		btn	=	(JButton) e.getSource();
		System.out.println(btn.getText() + "버튼클릭");
		switch(btn.getText()) {
		case "Add" :
			//when clicked 'Add' n times in a row
			if (cProc != null)
				cProc.dispose(); 
			//close the original one
			cProc = new CountryProc(); break;
			//then open the new one.
		case "Refresh" : jTableRefresh(); break;
		case "Currency" : try {
				new ApplicationController();
			} catch (IOException | SAXException | ParserConfigurationException e1) {
				e1.printStackTrace();
			} break;
		}
		
	}
	




	//Mouse event for when clicking data in the main Table
	@Override
	public void mouseClicked(MouseEvent arg0) {
		int		r = jTable.getSelectedRow();
		int		c = jTable.getSelectedColumn();
		String name = (String) jTable.getValueAt(r, 0);
		if(cProc != null)
			cProc.dispose();
			cProc = new CountryProc(name, this);
		
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	
	
	
	
	
	
}
