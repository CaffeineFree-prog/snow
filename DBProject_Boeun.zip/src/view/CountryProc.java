package view;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import model.*;

public class CountryProc extends JFrame 
	implements ActionListener {
	/*
	country NAME	VARCHAR2(20 BYTE)
	CAPITAL	VARCHAR2(20 BYTE)--
	CURRENCY	VARCHAR2(20 BYTE)--
	LANGUAGE	VARCHAR2(30 BYTE)
	HEADOFGOVERN	VARCHAR2(50 BYTE)--
	*/
	JPanel 					p;
	JTextField				tfCap, tfcurr, tfhog;
	JComboBox				cbCountry, cbLang1, cbLang2, cbLang3;
	JButton					btnInsert, btnCancel, btnUpdate, btnDelete;
	
	GridBagLayout			gb;
	GridBagConstraints		gbc;
	
	CountryList				countryList;
	
	
	public CountryProc() {
		
		//Components of a new table that shows up
		//when clicked 'add'in the main
		initComponent();
		btnEditOnOff(false);
		
		
	}
	//when clicked 'add' in the main
	public CountryProc(CountryList countryList) {
		this();
		this.countryList = countryList;
	}
	
	//when selected a data in the main
	public CountryProc(String name, CountryList countryList) {
		
		this(); //Call CountryProc() that has initComponent();
		this.cbCountry.setSelectedItem(name);
		this.countryList = countryList;
		
		viewData(name);
		
		btnEditOnOff(true);
		this.btnCancel.setVisible(false);
	}
	private void btnEditOnOff(boolean b) {
		
		this.btnInsert.setEnabled(!b);
		this.btnDelete.setEnabled(b);
		this.btnUpdate.setEnabled(b);
		this.btnCancel.setEnabled(true);
		
	}
	//sprinkle the data onto the 'Add a coutry' Table.
	private void viewData(String CN) {
		CountriesDao mDao = new CountriesDao();
		CountriesVO	   vo = mDao.getCountry(CN);
		
		this.cbCountry.setSelectedItem(vo.getName());
		this.tfCap.setText(vo.getCapital());
		this.tfcurr.setText(vo.getCurrency());
		this.cbLang1.setSelectedItem(vo.getLanguage());
		this.tfhog.setText(vo.getHeadofgovern());
		
	}
	//Components of a new table that shows up when clicked 'add'in the main
	private void initComponent() {
		this.setTitle("Add a country");
		
		gb			=	new GridBagLayout();
		this.setLayout(gb);
		gbc			=	new GridBagConstraints();
		gbc.fill	=	GridBagConstraints.BOTH;
		gbc.weightx = 1.0;
		gbc.weighty = 1.0;
		
		//CountryName
		JLabel	lblCN		=	new JLabel("Country Name");
		String [] arrCN		=	{"Select","Afghanistan","Albania","Algeria","Andorra","Angola","Argentina","Armenia","Australia","Azerbaijan","The Bahamas","Bangladesh","Barbados"
				,"Belarus","Belize","Benin","Bhutan","Botswana","Brazil","Brunei","Bulgaria","Burkina Faso","Burundi","Cambodia","Cameroon","Canada","Cape Verde","Chad"
				,"Chile","China","Colombia","Comoros","Costa Rica","Croatia","Cuba","Cyprus","Czech Republic","Denmark","Djibouti","Dominican Republic","Ecuador","Egypt"
				,"El Salvador","Equatorial Guinea","Eritrea","Estonia","Ethiopia","Fiji","Gabon","The Gambia","Georgia","Ghana","Guatemala","Guinea","Guinea-Bissau","Guyana"
				,"Haiti","Honduras","Hungary","Iceland","India","Indonesia","Iran","Iraq","Israel","Italy","Jamaica","Japan","Jordan","Kazakhstan","Kenya","Kiribati"
				,"Korea, North","Korea, South","Kuwait","Kyrgyzstan","Laos","Latvia","Lebanon","Lesotho","Liberia","Libya","Liechtenstein","Lithuania","Macedonia","Madagascar"
				,"Malawi","Malaysia","Maldives","Mali","Malta","Marshall Islands","Mauritania","Mauritius","Mexico","Moldova","Monaco","Mongolia","Montenegro","Morocco"
				,"Mozambique","Myanmar (Burma)","Namibia","Nepal","New Zealand","Nicaragua","Niger","Nigeria","Norway","Pakistan","Palau","Panama","Papua New Guinea"
				,"Paraguay","Peru","Philippines","Poland","Romania","Russia","Rwanda","San Marino","Saudi Arabia","Senegal","Serbia","Sierra Leone","Singapore","Slovakia"
				,"Somalia","South Sudan","Sudan","Suriname","Swaziland","Sweden","Syria","Taiwan","Tajikistan","Thailand","Togo","Tonga","Tunisia","Turkey","Turkmenistan"
				,"Uganda","Ukraine","United Kingdom","Uruguay","Uzbekistan","Vanuatu","Venezuela","Vietnam","Yemen","Zambia","Zimbabwe","Others"};
		cbCountry 			= new JComboBox(arrCN);
		gbAdd(lblCN, 0,0,1,1);
		gbAdd(cbCountry, 1,0,3,1);
		
		//Capital
		JLabel	lblCap = new JLabel("Capital");
		tfCap		   = new JTextField(30);
		gbAdd(lblCap, 0,1,1,1);
		gbAdd(tfCap, 1,1,3,1);
		
		//Currency
		JLabel lblCurr = new JLabel("Currency");
		tfcurr		   = new JTextField(30);
		gbAdd(lblCurr, 0,2,1,1);
		gbAdd(tfcurr, 1,2,3,1);
		
		//Language
		JLabel lblLang = new JLabel("Language");
		String [] arrLang1 = {"Select","Afrikaans","Albanian","Amharic","Arabic","Armenian","Azerbaijani","Bangla","Bau Fijian","Belarusian","Bislama","Bulgarian","Burmese","Catalan"
				,"Chinese and Malay","Comorian","Czech","Danish","Dari Persian","Dhivehi","Dutch","Dzongkha","English","Estonian","Filipino","French","Georgian","German"
				,"Gilbertese","Greek","Guarani","Haitian Creole","Hebrew","Hindi","Hungarian","Icelandic","Indonesian","Italian","Japanese","Kazakh","Khmer","Kirundi"
				,"Korean","Kuna","Kurdish","Kyrgyz","Lao (Laotian)","Latvian","Lithuanian","Luganda","Macedonian","Malagasy","Malay","Maltese","Mandarin","Marshallese"
				,"Moldovan (Romanian)","Mongolian","Montenegrin","Nepali","Norwegian","Palauan","Persian","Polish","Portuguese","Portuguese","Romanian","Russian","Serbian"
				,"Sesotho","Shona","Slovak","Somali Arabic","Spanish","Standard Chinese","Swahili","Swati","Swedish","Tajik","Tamazight","Thai","Tigrinya","Tok Pisin"
				,"Tswana","Turkish","Turkmen","Ukrainian","Urdu","Uzbek","Vietnamese","Others"};
		cbLang1			= new JComboBox(arrLang1);
		gbAdd(lblLang, 0,3,1,1);
		gbAdd(cbLang1, 1,3,3,1);
		
		//head of govern
		JLabel lblHOG	=	new JLabel("Head of Govern");
		tfhog			= 	new JTextField(70);
		gbAdd(lblHOG, 0,4,1,1);
		gbAdd(tfhog, 1,4,3,1);
		
		JPanel  pButton	=	new JPanel();
		btnInsert = new JButton("Add");
		btnUpdate = new JButton("Update");
		btnDelete = new JButton("Delete");
		btnCancel = new JButton("Cancel");
		pButton.add(btnInsert);
		pButton.add(btnUpdate);
		pButton.add(btnDelete);
		pButton.add(btnCancel);
		gbAdd(pButton, 0,5,4,1);
		
		this.btnInsert.addActionListener(this);
		this.btnUpdate.addActionListener(this);
		this.btnDelete.addActionListener(this);
		this.btnCancel.addActionListener(this);
		
		this.setSize(500,500);
		this.setLocation(100,100); //눌러졌을때 창이뜨는 위치
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		this.setVisible(true);
	}

	private void gbAdd(JComponent c, int x, int y, int w, int h) {
		gbc.gridx 			= x;
		gbc.gridy 			= y;
		gbc.gridwidth 		= w;
		gbc.gridheight 		= h;
		gb.setConstraints(c, gbc);
		gbc.insets			= new Insets(2, 2, 2, 2);
		this.add(c, gbc);
	}
	// Event process list
	@Override
	public void actionPerformed(ActionEvent e) {
		JButton btn = (JButton) e.getSource();
		switch(btn.getText()) {
		case "Add" : insertCountry(); break;
		case "Update" : updateCountry(); break;
		case "Delete" : deleteCountry(); break;
		case "Cancel" : this.dispose(); break;
		}
		
	}
	private void insertCountry() {
		CountriesDao mDao = new CountriesDao();
		CountriesVO   vo  = getViewData();
		mDao.insertCountry(vo);
		countryList.jTableRefresh();
		this.dispose();
		
	}
	private void updateCountry() {
		CountriesDao mDao	=	new CountriesDao();
		CountriesVO		vo  =	getViewData();
		//getViewData is to be updated
		//then throw it to vo, then edit vo
		boolean 		ok  = mDao.updateMember(vo);
		System.out.println(ok);
		
		if(ok == true) {
			countryList.jTableRefresh();
			String message = "수정되었습니다";
			System.out.println(message);
			JOptionPane.showMessageDialog(this, message);
			this.dispose();
		} else {
			String message = "수정되지 않았습니다";
			System.out.println(message);
			JOptionPane.showMessageDialog(this, message);
		}
		
	}
	private void deleteCountry() {

		CountriesDao	mDao	=	new CountriesDao();
		CountriesVO		vo		=	getViewData();
		String			CN		=	vo.getName().trim();
		
		if(CN.equals("")) {
			String message = "Country name is mandatory";
			JOptionPane.showMessageDialog(this, message);
			return;
		}
		if ( ! CN.equals(cbCountry.getSelectedItem())) {
			String message = "Country name is misspelled";
			JOptionPane.showMessageDialog(this, message);
			return;
		}
		
		int x = JOptionPane.showConfirmDialog(this,
				"Are you sure?", "delete",JOptionPane.YES_NO_OPTION);
		if(x == JOptionPane.NO_OPTION) return;
		boolean ok = mDao.deleteMember(vo);
		if(ok == true) { //if it's deleted
			countryList.jTableRefresh();
			String message = "It has been deleted";
			System.out.println(message);
			JOptionPane.showMessageDialog(this, message);
			this.dispose();
		} else {
			String message = "An error occured";
			System.out.println(message);
			JOptionPane.showMessageDialog(this, message);
		}
		
		
		
	}
	//input typed data into CountriesVO
	private CountriesVO getViewData() {
		CountriesVO vo	=	new CountriesVO();

		String name 		= (String) this.cbCountry.getSelectedItem();
		vo.setName(name);
		String capital		= this.tfCap.getText();
		vo.setCapital(capital);
		String currency		= this.tfcurr.getText();	
		vo.setCurrency(currency);
		String language		= (String) this.cbLang1.getSelectedItem();
		vo.setLanguage(language);
		String headofgovern = this.tfhog.getText();
		vo.setHeadofgovern(headofgovern);
		
		return vo;
	}

}
