package model;

import java.sql.*;

public class DBConn {
	
	//Oracle
	private static final String driver = "oracle.jdbc.OracleDriver";
	private static final String url	   = "jdbc:oracle:thin:@localhost:1521:xe";
	
	private static final String dbUid  = "boeun";
	private static final String dbPwd  = "1234";
	
	private static Connection	conn   = null;
	
	private DBConn() {
		
	}
	
	//Singleton
	public static Connection getInstance() {
		if(conn!= null)
			return conn; 
		
			try {
				Class.forName(driver);
				conn = DriverManager.getConnection(url, dbUid, dbPwd);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			
		return conn;
	}
	
	
	
	

}
