package model;

public class CountriesVO {
	private String name;
	private String capital;
	private String currency;
	private String language;
	private String headofgovern;
	
	//Constructor
	public CountriesVO() {
		
	}
	public CountriesVO(String name, String capital, String currency, String language, String headofgovern) {
		this.name = name;
		this.capital = capital;
		this.currency = currency;
		this.language = language;
		this.headofgovern = headofgovern;
	}
	//Getter Setter
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCapital() {
		return capital;
	}
	public void setCapital(String capital) {
		this.capital = capital;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public String getHeadofgovern() {
		return headofgovern;
	}
	public void setHeadofgovern(String headofgovern) {
		this.headofgovern = headofgovern;
	}
	//ToString
	@Override
	public String toString() {
		return "CountriesVO [name=" + name + ", capital=" + capital + ", currency=" + currency + ", language="
				+ language + ", headofgovern=" + headofgovern + "]";
	}

}
