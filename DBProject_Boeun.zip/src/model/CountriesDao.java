package model;

import java.sql.*;
import java.util.*;

public class CountriesDao {
	
	public CountriesDao() {
		
	}

	public Vector getMemberList() {
		
		Vector				v	=	new Vector();
		
		Connection		  conn	=	null;
		PreparedStatement pstmt =	null;
		ResultSet			rs  =	null;
		String			   sql	=	"";
		
		conn	=	DBConn.getInstance();
		sql		= "SELECT * FROM COUNTRIES2 ORDER BY NAME ASC";
		
		try {
			pstmt	= conn.prepareStatement(sql);
			rs		= pstmt.executeQuery();
			while(rs.next()) {
				Vector member	=	new Vector();
				//another Vector in Vector
				member.add(rs.getString("name"));
				member.add(rs.getString("capital"));
				member.add(rs.getString("currency"));
				member.add(rs.getString("language"));
				member.add(rs.getString("headofgovern"));
				v.add(member);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null)	 rs.close();
				if(pstmt!=null)	 pstmt.close();
				// close conn only when program exit
				// otherwise, it closes whenever select,insert, etc
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return v;
	}

	public void insertCountry(CountriesVO vo) {
		Connection			conn = null;
		PreparedStatement	pstmt= null;
		String 				sql  = "";
		
		conn	=	DBConn.getInstance();
		try {
			sql		= "INSERT INTO countries2 (NAME,CAPITAL,CURRENCY,LANGUAGE,HEADOFGOVERN)";
			sql		+= " VALUES (?,?,?,?,?)";
			pstmt	=	conn.prepareStatement(sql);
			pstmt.setString(1,  vo.getName()  	 	 );
			pstmt.setString(2,  vo.getCapital()  	 );
			pstmt.setString(3,  vo.getCurrency()  	 );
			pstmt.setString(4,  vo.getLanguage() 	 );
			pstmt.setString(5,  vo.getHeadofgovern() );
			pstmt.executeUpdate();
			
			System.out.println("saved");
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		
	}
	
	//when asked for CoutriesVO's data by 'country name' input
	public CountriesVO getCountry(String CN) {
		Connection			conn;
		PreparedStatement	pstmt;
		ResultSet			rs;
		String				sql = "";
		
		CountriesVO			vo = null;
		conn	=	DBConn.getInstance();
		
		try {
			sql 	= "SELECT NAME,CAPITAL,CURRENCY,LANGUAGE,HEADOFGOVERN";
			sql		+= " FROM COUNTRIES2";
			sql		+= " WHERE NAME = ?";
			pstmt	=	conn.prepareStatement(sql);
			pstmt.setString(1, CN);
			rs		=	pstmt.executeQuery();
			if(rs.next()) {
				String name			= rs.getString("name");
				String capital		= rs.getString("capital");
				String currency		= rs.getString("currency");
				String language		= rs.getString("language");
				String headofgovern	= rs.getString("headofgovern");
				vo = new CountriesVO(name,capital,currency,language,headofgovern);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return vo;
	}

	public boolean updateMember(CountriesVO vo) {
		boolean ok = false;
		
		Connection 	   	   conn = null;
		PreparedStatement pstmt = null;
		String				sql = "";
		
		
		try {
			conn	=	DBConn.getInstance();
			sql		=	"UPDATE COUNTRIES2";
			sql		+= " SET CAPITAL = ?, CURRENCY = ?, LANGUAGE = ?, HEADOFGOVERN = ?";
			sql		+= " WHERE NAME = ?";
			pstmt	=	conn.prepareStatement(sql);
			
			pstmt.setString(1, vo.getCapital()		);
			pstmt.setString(2, vo.getCurrency()		);
			pstmt.setString(3, vo.getLanguage()		);
			pstmt.setString(4, vo.getHeadofgovern() );
			pstmt.setString(5, vo.getName()			);
			
			int aftcnt	=	pstmt.executeUpdate();
			if(aftcnt != 0) // whether sql is executed
				//if SP is executed 1, it not 0
				ok = true;
			
			System.out.println("updated");
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				if(pstmt != null) pstmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		return ok;
	}

	public boolean deleteMember(CountriesVO vo) {
		boolean ok				=	false; //it's not deleted
		Connection conn			=	null;
		PreparedStatement pstmt =	null;
		String sql				=	"";
		
		try {
			conn 	= DBConn.getInstance();
			sql		= "DELETE FROM COUNTRIES2";
			sql		+= " WHERE NAME = ?";
			pstmt 	= conn.prepareStatement(sql);
			pstmt.setString(1, vo.getName());
			
			int aftcnt = pstmt.executeUpdate();
			if(aftcnt != 0) ok = true;
		} catch (SQLException e) {
			e.printStackTrace();
		} 
		
		return ok;
	}

}
