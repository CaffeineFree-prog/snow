package curr;

import javax.swing.*;

public interface SetText {
    public void setText(Object object, String string);
}
