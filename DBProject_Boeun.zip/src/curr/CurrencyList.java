package curr;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.*;

public class CurrencyList {
    private  Map<String,Integer> currencyMap;

    public Map<String,Integer> getCurrencyMap(){
        return currencyMap;
    }

    public  CurrencyList() throws ParserConfigurationException, IOException, SAXException {

        currencyMap= new LinkedHashMap<>();
        /*
        URL url=new URL("https://www.nbp.pl/kursy/xml/lasta.xml");
        HttpURLConnection connection=(HttpURLConnection)url.openConnection();
        InputStream inputStream=connection.getInputStream();

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(inputStream);
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName("pozycja");
         */
        Document xml = null;
		InputSource is = new InputSource(new FileReader("E:/workspace/html/converter.xml"));
		xml = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is);
		Element element = xml.getDocumentElement();
		NodeList nList = element.getElementsByTagName("countries");
		//NodeList list = element.getChildNodes();
		
		//-------------------------------------------------------------------
        
        for(int i=0;i<nList.getLength();i++){
            Node nNode = nList.item(i);
            Element eElement = (Element) nNode;
            String str = (String) eElement.getElementsByTagName("currency_name").item(0).getTextContent();
            System.out.println(str);
            currencyMap.put(str,i);
        }
    }
}
