package curr;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import org.w3c.dom.Element;

public class ApplicationModel {

    public  Currency extractData(int index) throws ParserConfigurationException, IOException, SAXException {
    	/*
        URL url=new URL("https://www.nbp.pl/kursy/xml/lasta.xml");
        HttpURLConnection connection=(HttpURLConnection)url.openConnection();
        InputStream inputStream=connection.getInputStream();


        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(inputStream);
        doc.getDocumentElement().normalize();
        NodeList nList = doc.getElementsByTagName("pozycja");
        */
    	Document xml = null;
		InputSource is = new InputSource(new FileReader("E:/workspace/html/converter.xml"));
		xml = DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(is);
		Element element = xml.getDocumentElement();
		NodeList nList = element.getElementsByTagName("countries");
		NodeList list = element.getChildNodes();
		
        

    		Node node=nList.item(index);
    		Element eElement = (Element) node ;
    		Currency currency=new Currency();
    		String tempString=eElement.getElementsByTagName("currency_rate").item(0).getTextContent();
    		String newString=tempString.replace(",",".");
    		currency.setAverageRate(Double.parseDouble(newString));
    		currency.setConversionRate(Integer.parseInt(eElement.getElementsByTagName("converter").item(0).getTextContent()));
    		//inputStream.close();
    		
    		return currency;
		
    	
    	//-------------------------------------------------------------------
        
        //Element element=(Element)node;
        //Currency currency=new Currency();
        //String tempString=element.getElementsByTagName("currency_rate").item(0).getTextContent();
        //String newString=tempString.replace(",",".");
        //currency.setAverageRate(Double.parseDouble(newString));
        //currency.setConversionRate(Integer.parseInt(element.getElementsByTagName("converter").item(0).getTextContent()));
        //inputStream.close();
       // return currency;
    }
}
