package curr;

import javax.swing.*;
import java.awt.*;

public interface AdjustComponent {
    public  void setComponent(LayoutManager layoutManager,JPanel jPanel,String string,Component component,boolean value);
}
