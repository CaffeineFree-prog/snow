package curr;

public interface GetText {
    public String getText(Object object);
}
