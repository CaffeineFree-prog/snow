package curr;

import javax.swing.*;

public class CheckIfNumber {
    public static boolean isNumeric(String text, JFrame jFrame){
        if(text==null){
            JOptionPane.showMessageDialog(jFrame,"Input the amount!");
            return false;
        }
        try{
            double d=Double.parseDouble(text);

        }catch (NumberFormatException exception){
            JOptionPane.showMessageDialog(jFrame,"Enter an integer or a floating point number without spaces!");
            return false;
        }
        return true;
    }
}
